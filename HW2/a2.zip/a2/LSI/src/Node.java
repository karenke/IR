
public class Node {

	int index;
	double cosine;
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public double getCosine() {
		return cosine;
	}
	public void setCosine(double cosine) {
		this.cosine = cosine;
	}
	public Node(int index, double cosine) {
		super();
		this.index = index;
		this.cosine = cosine;
	}
	
}
