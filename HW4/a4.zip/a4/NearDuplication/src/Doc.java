
public class Doc {

	int id;
	double sim;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getSim() {
		return sim;
	}
	public void setSim(double sim) {
		this.sim = sim;
	}
	public Doc(int id, double sim) {
		super();
		this.id = id;
		this.sim = sim;
	}
	
}
